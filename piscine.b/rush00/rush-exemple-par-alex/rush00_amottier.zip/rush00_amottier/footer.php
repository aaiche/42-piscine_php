<?php

echo '<div>
        <p>Copyright &copy; My Shop 2018</p>
      </div>';

?>